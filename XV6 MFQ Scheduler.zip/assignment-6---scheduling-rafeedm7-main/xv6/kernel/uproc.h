struct uproc {
    int pid;
    int ppid;
    int state;
    int sz;
    char name[16];
    int priority;       // Current priority level
    int ticks;          // Ticks used within the current quantum
    int blocks;         // Number of times process has blocked
    int full;           // Full quantum completions at the current priority level
};
