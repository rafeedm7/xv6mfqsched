#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "uproc.h"
#include "sysinfo.h"

struct cpu cpus[NCPU];

struct proc proc[NPROC];

//priority queues
struct proc *priority3[NPROC];
int numprocs3 = 0;
struct proc *priority2[NPROC];
int numprocs2 = 0;
struct proc *priority1[NPROC];
int numprocs1 = 0;
struct proc *priority0[NPROC];
int numprocs0 = 0;

struct proc *initproc;

int nextpid = 1;
struct spinlock pid_lock;

extern void forkret(void);
static void freeproc(struct proc *p);

extern char trampoline[]; // trampoline.S

// helps ensure that wakeups of wait()ing
// parents are not lost. helps obey the
// memory model when using p->parent.
// must be acquired before any p->lock.
struct spinlock wait_lock;

// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
  }
}

// initialize the proc table.
void
procinit(void)
{
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
  initlock(&wait_lock, "wait_lock");
  
  for(int i = 0; i < NPROC; i++) {
      priority3[i] = 0;
      priority2[i] = 0;
      priority1[i] = 0;
      priority0[i] = 0;
  }

  for(p = proc; p < &proc[NPROC]; p++) {
      initlock(&p->lock, "proc");
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
      p->priority = 3; //new processes begin at priority level 3
      p->ticks = 0;
      p->blocks = 0;
      p->quantum_used = 0;

  }

  struct cpu *c;
  for(c = cpus; c < &cpus[NCPU]; c++)
  {
    c->enabled = 0;
  }
}

// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
  int id = r_tp();
  return id;
}

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
  int id = cpuid();
  struct cpu *c = &cpus[id];
  return c;
}

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
  push_off();
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
  pop_off();
  return p;
}

int
allocpid()
{
  int pid;
  
  acquire(&pid_lock);
  pid = nextpid;
  nextpid = nextpid + 1;
  release(&pid_lock);

  return pid;
}

// Look in the process table for an UNUSED proc.
// If found, initialize state required to run in the kernel,
// and return with p->lock held.
// If there are no free procs, or a memory allocation fails, return 0.
static struct proc*
allocproc(void)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    acquire(&p->lock);
    if(p->state == UNUSED) {
      goto found;
    } else {
      release(&p->lock);
    }
  }
  return 0;

found:
  p->pid = allocpid();
  p->state = USED;

  // Allocate a trapframe page.
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // An empty user page table.
  p->pagetable = proc_pagetable(p);
  if(p->pagetable == 0){
    freeproc(p);
    release(&p->lock);
    return 0;
  }

  // Set up new context to start executing at forkret,
  // which returns to user space.
  memset(&p->context, 0, sizeof(p->context));
  p->context.ra = (uint64)forkret;
  p->context.sp = p->kstack + PGSIZE;

  return p;
}

// free a proc structure and the data hanging from it,
// including user pages.
// p->lock must be held.
static void
freeproc(struct proc *p)
{
  if(p->trapframe)
    kfree((void*)p->trapframe);
  p->trapframe = 0;
  if(p->pagetable)
    proc_freepagetable(p->pagetable, p->sz);
  p->pagetable = 0;
  p->sz = 0;
  p->pid = 0;
  p->parent = 0;
  p->name[0] = 0;
  p->chan = 0;
  p->killed = 0;
  p->xstate = 0;
  p->state = UNUSED;
}

// Create a user page table for a given process, with no user memory,
// but with trampoline and trapframe pages.
pagetable_t
proc_pagetable(struct proc *p)
{
  pagetable_t pagetable;

  // An empty page table.
  pagetable = uvmcreate();
  if(pagetable == 0)
    return 0;

  // map the trampoline code (for system call return)
  // at the highest user virtual address.
  // only the supervisor uses it, on the way
  // to/from user space, so not PTE_U.
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
              (uint64)trampoline, PTE_R | PTE_X) < 0){
    uvmfree(pagetable, 0);
    return 0;
  }

  // map the trapframe page just below the trampoline page, for
  // trampoline.S.
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
              (uint64)(p->trapframe), PTE_R | PTE_W) < 0){
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    uvmfree(pagetable, 0);
    return 0;
  }

  return pagetable;
}

// Free a process's page table, and free the
// physical memory it refers to.
void
proc_freepagetable(pagetable_t pagetable, uint64 sz)
{
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
  uvmfree(pagetable, sz);
}

// a user program that calls exec("/init")
// assembled from ../user/initcode.S
// od -t xC ../user/initcode
uchar initcode[] = {
  0x17, 0x05, 0x00, 0x00, 0x13, 0x05, 0x45, 0x02,
  0x97, 0x05, 0x00, 0x00, 0x93, 0x85, 0x35, 0x02,
  0x93, 0x08, 0x70, 0x00, 0x73, 0x00, 0x00, 0x00,
  0x93, 0x08, 0x20, 0x00, 0x73, 0x00, 0x00, 0x00,
  0xef, 0xf0, 0x9f, 0xff, 0x2f, 0x69, 0x6e, 0x69,
  0x74, 0x00, 0x00, 0x24, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00
};

// Set up first user process.
void
userinit(void)
{
  struct proc *p;

  p = allocproc();
  initproc = p;
  
  // allocate one user page and copy initcode's instructions
  // and data into it.
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
  p->sz = PGSIZE;

  // prepare for the very first "return" from kernel to user.
  p->trapframe->epc = 0;      // user program counter
  p->trapframe->sp = PGSIZE;  // user stack pointer

  safestrcpy(p->name, "initcode", sizeof(p->name));
  p->cwd = namei("/");

  p->state = RUNNABLE;

  p->trace = 0;

  p->priority = 3;
  p->ticks = 0;
  mfq_enqueue(p, p->priority);


  release(&p->lock);
}

// Grow or shrink user memory by n bytes.
// Return 0 on success, -1 on failure.
int
growproc(int n)
{
  uint64 sz;
  struct proc *p = myproc();

  sz = p->sz;
  if(n > 0){
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
      return -1;
    }
  } else if(n < 0){
    sz = uvmdealloc(p->pagetable, sz, sz + n);
  }
  p->sz = sz;
  return 0;
}

// Create a new process, copying the parent.
// Sets up child kernel stack to return as if from fork() system call.
int
fork(void)
{
  int i, pid;
  struct proc *np;
  struct proc *p = myproc();

  // Allocate process.
  if((np = allocproc()) == 0){
    return -1;
  }

  // Copy user memory from parent to child.
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    freeproc(np);
    release(&np->lock);
    return -1;
  }
  np->sz = p->sz;

  // copy saved user registers.
  *(np->trapframe) = *(p->trapframe);

  // Cause fork to return 0 in the child.
  np->trapframe->a0 = 0;

  // increment reference counts on open file descriptors.
  for(i = 0; i < NOFILE; i++)
    if(p->ofile[i])
      np->ofile[i] = filedup(p->ofile[i]);
  np->cwd = idup(p->cwd);

  safestrcpy(np->name, p->name, sizeof(p->name));

  pid = np->pid;

  release(&np->lock);

  acquire(&wait_lock);
  np->parent = p;
  release(&wait_lock);

  acquire(&np->lock);
  np->state = RUNNABLE;
  np->ticks = 0;
  mfq_enqueue(np, np->priority);
  release(&np->lock);

  np->trace = p->trace;

  return pid;
}

// Pass p's abandoned children to init.
// Caller must hold wait_lock.
void
reparent(struct proc *p)
{
  struct proc *pp;

  for(pp = proc; pp < &proc[NPROC]; pp++){
    if(pp->parent == p){
      pp->parent = initproc;
      wakeup(initproc);
    }
  }
}

// Exit the current process.  Does not return.
// An exited process remains in the zombie state
// until its parent calls wait().
void
exit(int status)
{
  struct proc *p = myproc();
  //remove_from_queue(p, p->priority);

  if(p == initproc)
    panic("init exiting");

  // Close all open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(p->ofile[fd]){
      struct file *f = p->ofile[fd];
      fileclose(f);
      p->ofile[fd] = 0;
    }
  }

  begin_op();
  iput(p->cwd);
  end_op();
  p->cwd = 0;

  acquire(&wait_lock);

  // Give any children to init.
  reparent(p);

  // Parent might be sleeping in wait().
  wakeup(p->parent);
  
  acquire(&p->lock);

  p->xstate = status;
  p->state = ZOMBIE;
  mfq_dequeue(p, p->priority);

  release(&wait_lock);

  // Jump into the scheduler, never to return.
  sched();
  panic("zombie exit");
}

// Wait for a child process to exit and return its pid.
// Return -1 if this process has no children.
int
wait(uint64 addr)
{
  struct proc *pp;
  int havekids, pid;
  struct proc *p = myproc();

  acquire(&wait_lock);

  for(;;){
    // Scan through table looking for exited children.
    havekids = 0;
    for(pp = proc; pp < &proc[NPROC]; pp++){
      if(pp->parent == p){
        // make sure the child isn't still in exit() or swtch().
        acquire(&pp->lock);

        havekids = 1;
        if(pp->state == ZOMBIE){
          // Found one.
          pid = pp->pid;
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
                                  sizeof(pp->xstate)) < 0) {
            release(&pp->lock);
            release(&wait_lock);
            return -1;
          }
          freeproc(pp);
          release(&pp->lock);
          release(&wait_lock);
          return pid;
        }
        release(&pp->lock);
      }
    }

    // No point waiting if we don't have any children.
    if(!havekids || killed(p)){
      release(&wait_lock);
      return -1;
    }
    
    // Wait for a child to exit.
    sleep(p, &wait_lock);  //DOC: wait-sleep
  }
}


struct proc* mfq_peek(void) {
    struct proc **queue = 0;
    int num_procs = 0;

    // Iterate from highest to lowest priority to find a runnable process.
    for (int priority = 3; priority >= 0; priority--) {
        switch (priority) {
            case 3:
                queue = priority3;
                num_procs = numprocs3;
                break;
            case 2:
                queue = priority2;
                num_procs = numprocs2;
                break;
            case 1:
                queue = priority1;
                num_procs = numprocs1;
                break;
            case 0:
                queue = priority0;
                num_procs = numprocs0;
                break;
        }

        // Return the first runnable process found in the highest priority queue.
        for (int i = 0; i < num_procs; i++) {
            if (queue[i]->state == RUNNABLE) {
                return queue[i];
            }
        }
    }

    // No runnable process found
    return 0;

    // dynamic_priority_adjustment();
}
 


void scheduler(void)
{
    struct proc *p;
    struct cpu *c = mycpu(); // Obtain the current CPU data.
    c->enabled = 1;          // Enable current CPU for scheduling processes.
    c->proc = 0;             // No process is initially running.

    // Infinite loop to keep the scheduler running.
    for (;;) {
        intr_on(); // Ensure interrupts are enabled at the beginning of the loop.

        while ((p = mfq_peek()) != 0) { // Continuously fetch the highest priority process that is ready to run.
            acquire(&p->lock); // Lock the process to change its state safely.

            if (p->state == RUNNABLE) {
                // Mark the process as running and set it as the current process on this CPU.
                p->state = RUNNING;
                c->proc = p;

                // Context switch to the process from the scheduler.
                swtch(&c->context, &p->context);

                // Process returns here after being switched out.
                c->proc = 0;
            }

            release(&p->lock); // Release the lock on the process after handling.

            // Process time slice and priority handling could be adjusted here.
            // if (p->ticks >= time_slice[p->priority]) {
            //     mfq_dequeue(p);
            //     if (p->priority > 0) p->priority--;
            //     mfq_enqueue(p);
            // }
        }

    }
}

//void enqueue(struct proc* p) {
  //int pr = p->priority;
  //queues[pr][tail[pr]++] = p;
//}

//struct proc* dequeue(int priority) {
  //struct proc* p = queues[priority][0];
  // Shift all elements to the left
  //for(int i = 0; i < tail[priority] - 1; i++) {
    //queues[priority][i] = queues[priority][i + 1];
  //}
  //tail[priority]--;
  //return p;
//}

//struct proc* peek(int priority) {
  //if (tail[priority] > 0)
    //return queues[priority][0];
  //return 0;
//}
// Enqueues a process into one of four priority queues based on its priority level.
void mfq_enqueue(struct proc *p, int priority) {
    struct proc **queue;  // Pointer to the selected priority queue
    int *numprocs;        // Pointer to the number of processes in the selected queue

    // Update the process's priority field with the provided priority.
    p->priority = priority;

    // Determine which queue to use based on the process's priority.
    switch (priority) {
        case 3:
            queue = priority3;  // Highest priority queue
            numprocs = &numprocs3;  // Pointer to the count of processes in priority 3 queue
            break;
        case 2:
            queue = priority2;  // Second-highest priority queue
            numprocs = &numprocs2;  // Pointer to the count of processes in priority 2 queue
            break;
        case 1:
            queue = priority1;  // Second-lowest priority queue
            numprocs = &numprocs1;  // Pointer to the count of processes in priority 1 queue
            break;
        case 0:
            queue = priority0;  // Lowest priority queue
            numprocs = &numprocs0;  // Pointer to the count of processes in priority 0 queue
            break;
        default:
            // Handle invalid priority inputs
            printf("%d Invalid priority\n", priority);
            return;
    }

    // Add the process to the appropriate queue if there is space.
    if (*numprocs < NPROC) {
        queue[*numprocs] = p;  // Place the process at the end of the queue
        (*numprocs)++;  // Increment the number of processes in the queue
    } else {
        // If the queue is full, print an error message indicating a queue overflow.
        printf("Queue overflow at priority %d\n", priority);
    }
}

// Dequeue a process from a specific priority queue.
void mfq_dequeue(struct proc *p, int priority) {
    struct proc **queue;
    int *numprocs;

    // Select the correct queue based on the provided priority.
    // Same logic as the enqueue
    switch (priority) {
        case 3:
            queue = priority3;
            numprocs = &numprocs3;
            break;
        case 2:
            queue = priority2;
            numprocs = &numprocs2;
            break;
        case 1:
            queue = priority1;
            numprocs = &numprocs1;
            break;
        case 0:
            queue = priority0;
            numprocs = &numprocs0;
            break;
        default:
            printf("Invalid priority\n");
            return;
    }

    // Search for and remove the process from the queue.
    for (int i = 0; i < *numprocs; i++) {
        if (queue[i] == p) {
            for (int j = i; j < *numprocs - 1; j++) {
                queue[j] = queue[j + 1];
            }
            queue[*numprocs - 1] = 0;
            (*numprocs)--;
            break;
        }
    }
}



//void mfq_enqueue(struct proc *p, int priority) {
    //if (priority < 0 || priority >= 4) {
        //printf("Invalid priority\n");
        //return;
    //}
    //if (queue_count[priority] < NPROC) {
        //priority_queues[priority][queue_count[priority]++] = p;
    //}
//}

//struct proc *mfq_dequeue(int priority) {
    //if (priority < 0 || priority >= 4 || queue_count[priority] == 0) {
        //return NULL;
    //}
    //struct proc *p = priority_queues[priority][0];
    //for (int i = 0; i < queue_count[priority] - 1; i++) {
        //priority_queues[priority][i] = priority_queues[priority][i + 1];
    //}
    //queue_count[priority]--;
    //return p;
//}
// Switch to scheduler.  Must hold only p->lock
// and have changed proc->state. Saves and restores
// intena because intena is a property of this
// kernel thread, not this CPU. It should
// be proc->intena and proc->noff, but that would
// break in the few places where a lock is held but
// there's no process.

//tails are confusing me, maybe come back to
//void proc_init(int pid) {
    // Allocate memory for a new process.
    //proc_t *new_proc = malloc(sizeof(proc_t));
    //if (new_proc == NULL) {
        //fprintf(stderr, "Memory allocation failed\n");
        //return;
    //}

    // Initialize the process.
    //new_proc->pid = pid;
    //new_proc->next = NULL; // As this is the most recent process, next is NULL.
    //new_proc->prev = tail; // The previous process is the current tail.

    // If the list is empty, this new process is both the head and tail.
    //if (tail == NULL) {
        //head = new_proc;
        //tail = new_proc;
    //} else {
        // Otherwise, update the old tail to point to this new process.
        //tail->next = new_proc;
        // And update the tail pointer to the new process.
        //tail = new_proc;
    //}
//}

void
sched(void)
{
  int intena;
  struct proc *p = myproc();

  if(!holding(&p->lock))
    panic("sched p->lock");
  if(mycpu()->noff != 1)
    panic("sched locks");
  if(p->state == RUNNING)
    panic("sched running");
  if(intr_get())
    panic("sched interruptible");

  intena = mycpu()->intena;
  swtch(&p->context, &mycpu()->context);
  mycpu()->intena = intena;
}

// Give up the CPU for one scheduling round.
void yield(void)
{
    struct proc *p = myproc();
    acquire(&p->lock);  // Lock the current process to modify its state.

    p->state = RUNNABLE;  // Change the state of the process to RUNNABLE.
    p->ticks += 1;  // Increment the tick count for the current quantum.

    // Determine the number of ticks needed for the current priority to trigger a priority change.
    int ticksNeeded = 0;
    switch (p->priority) {
        case 3: ticksNeeded = 2; break;
        case 2: ticksNeeded = 4; break;
        case 1: ticksNeeded = 8; break;
        case 0: ticksNeeded = 16; break;
    }

    // Check if the process has consumed its time slice.
    if (p->ticks >= ticksNeeded) {
        mfq_dequeue(p, p->priority);  // Remove the process from its current queue.
        if (p->priority > 0) {
            p->priority--;   // Decrease the priority since it used up its time slice.
        } else {
            p->quantum_used++;       // Increment the 'full' counter if the process is at lowest priority.
        }
        p->ticks = 0;    // Reset tick count for the new priority level.
        mfq_enqueue(p, p->priority);  // Re-enqueue the process at its new priority level.
    }

   
    // if (p->waiting_on_resource) {
    //     // Temporarily boost priority to prevent priority inversion.
    //     p->priority = 3;
    //     mfq_enqueue(p, p->priority);
   
    //     mfq_enqueue(p, p->priority);  // Consider shorter quantum for IO-bound processes.
    // }

    // Switch to the next process by calling the scheduler.
    sched();
    release(&p->lock);  // Release the lock after scheduling.
}



// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);

  if (first) {
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    first = 0;
    fsinit(ROOTDEV);
  }

  usertrapret();
}

// Atomically release lock and sleep on chan.
// Reacquires lock when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
  struct proc *p = myproc();
  
  // Must acquire p->lock in order to
  // change p->state and then call sched.
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
  release(lk);

  // Go to sleep.
  p->chan = chan;
  p->state = SLEEPING;
  mfq_dequeue(p, p->priority);
  p->ticks = 0;
  p->blocks += 1;

  sched();

  // Tidy up.
  p->chan = 0;

  // Reacquire original lock.
  release(&p->lock);
  acquire(lk);
}

// Wake up all processes sleeping on chan.
// Must be called without any p->lock.
void
wakeup(void *chan)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
        p->state = RUNNABLE;
	mfq_enqueue(p, p->priority);
      }
      release(&p->lock);
    }
  }
}

// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    acquire(&p->lock);
    if(p->pid == pid){
      p->killed = 1;
      if(p->state == SLEEPING){
        // Wake process from sleep().
        p->state = RUNNABLE;
	p->ticks = 0;
	mfq_enqueue(p, p->priority);
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
  }
  return -1;
}

void
setkilled(struct proc *p)
{
  acquire(&p->lock);
  p->killed = 1;
  release(&p->lock);
}

int
killed(struct proc *p)
{
  int k;
  
  acquire(&p->lock);
  k = p->killed;
  release(&p->lock);
  return k;
}

// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
  struct proc *p = myproc();
  if(user_dst){
    return copyout(p->pagetable, dst, src, len);
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}

// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
  struct proc *p = myproc();
  if(user_src){
    return copyin(p->pagetable, dst, src, len);
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}

// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
  static char *states[] = {
  [UNUSED]    "unused",
  [USED]      "used",
  [SLEEPING]  "sleep ",
  [RUNNABLE]  "runble",
  [RUNNING]   "run   ",
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
  for(p = proc; p < &proc[NPROC]; p++){
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
      state = states[p->state];
    else
      state = "???";
    printf("%d %s %s", p->pid, state, p->name);
    printf("\n");
  }
}

uint64
procinfo(uint64 proc_array, int max_procs)
{

struct proc *myp = myproc();
struct uproc cur_uproc;
struct proc *cur_proc;

if (max_procs < 1)
{
    return -1; // Return error if the provided size is not valid.
}

int i = 0;
for (cur_proc = proc; cur_proc < &proc[NPROC]; cur_proc++)
{
    acquire(&cur_proc->lock); // Lock each process struct as you read it.
    if (cur_proc->state == UNUSED || cur_proc->state == USED){
        release(&cur_proc->lock);
        continue; // Skip unused or just initialized processes not fully set up.
}
    cur_uproc.pid = cur_proc->pid;
    cur_uproc.state = cur_proc->state;
    cur_uproc.sz = cur_proc->sz;
    safestrcpy(cur_uproc.name, cur_proc->name, 16);


    cur_uproc.priority = cur_proc->priority;
    cur_uproc.ticks = cur_proc->ticks;
    cur_uproc.blocks = cur_proc->blocks;
    cur_uproc.full = cur_proc->quantum_used;


    // Populate new fields while holding the lock.
    // Handle parent PID acquisition.
    if  (cur_proc->parent) {
        acquire(&cur_proc->parent->lock);
        cur_uproc.ppid = cur_proc->parent->pid;
        release(&cur_proc->parent->lock);
  } 
    else {

        cur_uproc.ppid = 0;
    }
    release(&cur_proc->lock); // Release the current process lock.

    // Copy the populated uproc structure to user space.
    if (copyout(myp->pagetable, proc_array + i * sizeof(cur_uproc), (char *)&cur_uproc, sizeof(cur_uproc)) < 0)
    {
        return -1; // Handle errors in copying out data.
    }
        ++i;
	if (i == max_procs)
	{
		break;
	}
}
return i;
}




void
get_proc_sysinfo(struct sysinfo *info)
{
  struct proc *p;
  struct cpu *c;

  info->num_harts = 0;
  info->num_procs = 0;
  info->proc_mem = 0;

  for (p = proc; p < &proc[NPROC]; p++)
  {
    acquire(&p->lock);
    if (p->state == UNUSED || p->state == USED)
    {
      release(&p->lock);
      continue;
    }
    
    info->num_procs++;
    info->proc_mem += p->sz;
    release(&p->lock);
  }

  for (c = cpus; c < &cpus[NCPU]; c++)
  {
    if (c->enabled)
    {
      info->num_harts++;
    }
  }

  return;
}


